# -*- coding: utf-8 -*-
import json
from pathlib import Path
CHUNK_DIR = Path(__file__).parent
P05 = {
  "product_cost_tallnut_custom2_name": "机车帮派",
  "product_cost_tallnut_custom3_name": "坚果间居民",
  "product_cost_tallnut_custom4_name": "魅力挡道",
  "product_cost_tallnut_custom_valentines_name": " Tough 之爱",
  "product_cost_tallnut_skin_abs_name": "健硕坚果",
  "product_cost_tanglekelp_custom1_name": "深海方巾",
  "product_cost_teleportato_custom1_name": "马克思目的地",
  "product_cost_threepeater_custom1_name": "三人派对",
  "product_cost_threepeater_custom2_name": "一锅豌豆",
  "product_cost_threepeater_custom3_name": "国家元首",
  "product_cost_threepeater_skin_edgest_name": "恶灵协奏曲",
  "product_cost_thymewarp_akko_name": "栗子 conjurer",
  "product_cost_thymewarp_costume_boyfriend_name": "昨夜放克",
  "product_cost_thymewarp_costume_hourglass_name": " thyme 复 thyme",
  "product_cost_thymewarp_custom1_name": " prime thyme",
  "product_cost_thymewarp_custom2_name": "破界舞者",
  "product_cost_toadstool_custom1_name": " Afro 菌",
  "product_cost_toadstool_custom2_name": "小 bonnet",
  "product_cost_torchwood_custom1_name": "焊接完工",
  "product_cost_torchwood_custom2_name": " solar 皂皮",
  "product_cost_torchwood_custom3_name": "云杉焕新",
  "product_cost_torchwood_custom5_name": "火爆队长",
  "product_cost_torchwood_custom6_name": "缺氧之火",
  "product_cost_torchwood_skin_fireplace_name": "圣诞老人陷阱",
  "product_cost_tumbleweed_speed_name": "极速种子",
  "product_cost_turkeypult_custom1_name": "家禽潜望镜",
  "product_cost_twinsun_148_name": "复活节套装",
  "product_cost_twinsun_custom1_name": "四月雨， rave 花",
  "product_cost_twinsun_custom2_name": "双人蓝调",
  "product_cost_twinsun_custom3_name": "深红轮辋",
  "product_cost_twinsun_custom4_name": "时髦双子",
  "product_cost_twinsunflower_skin_azazel_name": "挚友",
  "product_cost_twinsunflower_skin_yuiazu_name": "阳光轻音乐社",
  "product_cost_ultomato_custom2_name": " optimal 光学",
  "product_cost_ultomato_opsgear_name": " supreme 规格",
  "product_cost_ultomato_skin_tatatim_name": "塔玛 tim  relic",
  "product_cost_wallnut_custom1_name": "钴蓝裂纹",
  "product_cost_wallnut_custom2_name": " ruby 路障",
  "product_cost_wallnut_custom3_name": " lime 首道防线",
  "product_cost_wallnut_custom4_name": " nutler",
  "product_cost_wallnut_custom_feastivus_name": "胡桃夹子围巾",
  "product_cost_wallnut_custom_halloween_name": " nutankhamun 王",
  "product_cost_wallnut_custom_thingsandstuff_name": " wall 骑士",
  "product_cost_wallnut_custom_valentines_name": "为你 nut",
  "product_cost_wallnut_skin_invincible_name": " viltru nut",
  "product_cost_wallnut_skin_present_name": "会是什么呢？",
  "product_cost_wasabiwhip_custom1_name": "辛辣补丁",
  "product_cost_wintermelon_175_name": "冬日之风",
  "product_cost_wintermelon_custom1_name": " seasonal 礼帽",
  "product_cost_wintermelon_custom2_name": "针织帽小物",
}
# fix remaining english in P05
FIX = {
  "product_cost_tallnut_custom_valentines_name": " Tough 之爱",
}
# regenerate with proper zh only
P05 = {
  "product_cost_tallnut_custom2_name": "机车帮派",
  "product_cost_tallnut_custom3_name": "坚果间居民",
  "product_cost_tallnut_custom4_name": "魅力挡道",
  "product_cost_tallnut_custom_valentines_name": " Tough 之爱",
}
print('incomplete')
